﻿//Demonstrate Sockets
using System;
using System.Net.Sockets;
using System.IO;
public class Whois
{
    static void Main(string[] args)
    {
        int argL;
        argL = args.Length;
        int c;
        TcpClient client = new TcpClient();
        client.Connect("whois.net.dcs.hull.ac.uk", 43);
        StreamWriter sw = new StreamWriter(client.GetStream());
        StreamReader sr = new StreamReader(client.GetStream());

        switch (argL)//swtch case on the number of command line arguments 
        {
            case 1:           
                sw.WriteLine(args[0]);
                sw.Flush();
                Console.Write(args[0]); //first argument(shoud be name)
                Console.Write(" is in the ");
                Console.WriteLine(sr.ReadToEnd());//read the location from server
                break;
            case 2:
                sw.Write(args[0][1]);
                sw.Flush();
                Console.Write(args[0][1]);
                
                Console.WriteLine(sr.ReadToEnd());
                break;
            default:
                break;             
        }
    }
}